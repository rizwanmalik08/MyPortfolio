import { motion } from 'framer-motion'

function About() {
  return (
    <section id="about" className="section">
      <div className="container">
        <motion.div
          className="glass grid gap-10 p-10 lg:grid-cols-[0.9fr_1.1fr]"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6 }}
        >
          <div className="space-y-6">
            <div className="rounded-3xl border border-white/10 bg-slate-950/70 p-6">
              <div className="flex items-center gap-4">
                <div className="h-20 w-20 rounded-3xl bg-gradient-to-br from-violet-400 to-sky-300 p-1">
                  <div className="flex h-full w-full items-center justify-center rounded-2xl bg-slate-950 text-xl font-semibold text-white">
                    M
                  </div>
                </div>
                <div>
                  <p className="text-lg font-semibold text-white">Malik</p>
                  <p className="text-sm text-slate-300">Frontend Developer</p>
                </div>
              </div>
              <p className="mt-4 text-sm text-slate-300">
                Clean, modern, and responsive design to elevate product teams.
              </p>
              <button className="mt-6 button-secondary">Download CV</button>
            </div>
          </div>
          <div>
            <p className="section-kicker">About Me</p>
            <h2 className="section-title">Who am I?</h2>
            <p className="mt-4 text-base text-slate-300">
              I am a passionate frontend developer with 3+ years of experience
              building beautiful and functional websites. I love turning ideas
              into real products and creating smooth user experiences.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-300">
              <li className="flex items-center gap-3">
                <span className="dot"></span>
                Clean, modern, and responsive design
              </li>
              <li className="flex items-center gap-3">
                <span className="dot"></span>
                Pixel perfect and accessible
              </li>
              <li className="flex items-center gap-3">
                <span className="dot"></span>
                Performance optimized code
              </li>
              <li className="flex items-center gap-3">
                <span className="dot"></span>
                Always learning new things
              </li>
            </ul>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default About
