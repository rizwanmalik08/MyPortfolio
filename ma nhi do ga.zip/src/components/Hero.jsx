import { motion } from 'framer-motion'

function Hero() {
  return (
    <section id="home" className="section pt-28">
      <div className="container grid items-center gap-12 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="space-y-6">
          <motion.p
            className="section-kicker"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Portfolio
          </motion.p>
          <motion.h1
            className="text-4xl font-semibold leading-tight text-white sm:text-5xl"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            Hi, I am
            <span className="block text-5xl sm:text-6xl">Malik</span>
            <span className="block bg-gradient-to-r from-violet-300 via-sky-300 to-white bg-clip-text text-transparent">
              Frontend Developer
            </span>
          </motion.h1>
          <motion.p
            className="text-lg text-slate-300"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            I build modern, responsive, and user-friendly websites using React,
            Tailwind CSS, and emerging UI technologies.
          </motion.p>
          <motion.div
            className="flex flex-wrap gap-4"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <a href="#projects" className="button-primary">
              View Projects
            </a>
            <a href="#contact" className="button-secondary">
              Contact Me
            </a>
          </motion.div>
          <motion.div
            className="flex flex-wrap items-center gap-4 border-t border-white/10 pt-6 text-sm text-slate-300"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <span className="pill">React Developer</span>
            <span className="pill">3+ Years Experience</span>
            <span className="pill">20+ Projects Completed</span>
          </motion.div>
        </div>
        <motion.div
          className="relative glass p-8"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="relative rounded-3xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 p-8">
            <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-violet-500/20 blur-2xl"></div>
            <div className="flex items-center gap-4">
              <div className="h-24 w-24 rounded-full bg-gradient-to-br from-violet-400 to-sky-300 p-1">
                <div className="flex h-full w-full items-center justify-center rounded-full bg-slate-950 text-2xl font-semibold text-white">
                  M
                </div>
              </div>
              <div>
                <p className="text-lg font-semibold text-white">Malik</p>
                <p className="text-sm text-slate-300">Frontend Developer</p>
                <div className="mt-3 flex gap-2 text-xs text-slate-300">
                  <span className="badge">React</span>
                  <span className="badge">UI</span>
                </div>
              </div>
            </div>
            <div className="mt-6 grid gap-4 text-xs uppercase tracking-[0.2em] text-slate-300 sm:grid-cols-2">
              <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-4">
                3+ Years
              </div>
              <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-4">
                20+ Projects
              </div>
              <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-4">
                React Expert
              </div>
              <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-4">
                UI Motion
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default Hero
