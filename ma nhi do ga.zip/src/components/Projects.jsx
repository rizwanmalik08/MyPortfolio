import { motion } from 'framer-motion'

const projects = [
  {
    title: 'Pulse Dashboard',
    description:
      'A metrics dashboard with modular cards, real-time filters, and a calm dark UI.',
    github: 'https://github.com/yourname/pulse-dashboard',
    demo: 'https://pulse-dashboard.example.com',
  },
  {
    title: 'Studio Landing',
    description:
      'Marketing site built with a modular section system and polished animations.',
    github: 'https://github.com/yourname/studio-landing',
    demo: 'https://studio-landing.example.com',
  },
  {
    title: 'TaskFlow',
    description:
      'A productivity app featuring kanban workflows and smooth drag interactions.',
    github: 'https://github.com/yourname/taskflow',
    demo: 'https://taskflow.example.com',
  },
]

function Projects() {
  return (
    <section id="projects" className="section">
      <div className="container">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="section-kicker">Projects</p>
            <h2 className="section-title">Selected work</h2>
          </div>
          <div className="flex flex-wrap gap-2 text-xs uppercase tracking-[0.2em]">
            {['All', 'React', 'Next.js', 'UI/UX'].map((tab) => (
              <button
                key={tab}
                type="button"
                className="rounded-full border border-white/10 px-4 py-2 text-slate-300 transition hover:border-white/30 hover:text-white"
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-10 grid gap-6 lg:grid-cols-3">
          {projects.map((project, index) => (
            <motion.article
              key={project.title}
              className="glass card-hover flex h-full flex-col p-6 text-white"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
            >
              <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 p-6">
                <div className="h-32 rounded-2xl border border-white/10 bg-slate-950/60"></div>
              </div>
              <div className="flex items-center justify-between text-xs uppercase tracking-[0.2em] text-slate-400">
                <span>Case Study</span>
                <span>{String(index + 1).padStart(2, '0')}</span>
              </div>
              <h3 className="text-lg font-semibold">{project.title}</h3>
              <p className="mt-3 text-sm text-slate-300">
                {project.description}
              </p>
              <div className="mt-6 flex gap-3">
                <a
                  href={project.github}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-white/20 px-4 py-2 text-xs font-semibold text-white transition hover:border-white/50 hover:bg-white/10"
                >
                  GitHub
                </a>
                <a
                  href={project.demo}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full bg-white px-4 py-2 text-xs font-semibold text-slate-950 transition hover:bg-slate-200"
                >
                  Live Demo
                </a>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Projects
