import { motion } from 'framer-motion'

const skills = [
  { name: 'React', detail: 'Component-driven UI', level: 90 },
  { name: 'JavaScript', detail: 'ES6+ and tooling', level: 85 },
  { name: 'Tailwind CSS', detail: 'Utility-first styling', level: 95 },
  { name: 'HTML5', detail: 'Semantic structure', level: 90 },
  { name: 'CSS3', detail: 'Responsive layouts', level: 88 },
]

function Skills() {
  return (
    <section id="skills" className="section">
      <div className="container">
        <div className="flex items-center justify-between">
          <div>
            <p className="section-kicker">Skills</p>
            <h2 className="section-title">My skills</h2>
          </div>
        </div>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-5">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              className="glass card-hover p-5 text-white"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
            >
              <div className="flex items-center justify-between">
                <div className="icon-chip">{skill.name.slice(0, 2)}</div>
                <span className="text-xs text-slate-400">{skill.level}%</span>
              </div>
              <h3 className="mt-4 text-sm font-semibold">{skill.name}</h3>
              <p className="mt-2 text-xs text-slate-400">{skill.detail}</p>
              <div className="mt-4 h-1.5 w-full rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-violet-400 to-sky-300"
                  style={{ width: `${skill.level}%` }}
                ></div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Skills
