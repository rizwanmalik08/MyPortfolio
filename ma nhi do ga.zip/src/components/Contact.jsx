import { motion } from 'framer-motion'

function Contact() {
  return (
    <section id="contact" className="section">
      <div className="container">
        <motion.div
          className="glass grid gap-10 p-10 lg:grid-cols-[1.1fr_0.9fr]"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6 }}
        >
          <form className="space-y-4">
            <div>
              <p className="section-kicker">Get in touch</p>
              <h2 className="section-title">Let us build something together</h2>
              <p className="mt-3 text-sm text-slate-300">
                Share the details of your next project and I will get back to you
                within 24 hours.
              </p>
            </div>
            <div>
              <label className="text-xs uppercase tracking-[0.2em] text-slate-400">
                Your Name
              </label>
              <input
                type="text"
                placeholder="Your name"
                className="mt-2 w-full rounded-2xl border border-white/10 bg-slate-950/60 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:border-white/40 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-xs uppercase tracking-[0.2em] text-slate-400">
                Your Email
              </label>
              <input
                type="email"
                placeholder="you@example.com"
                className="mt-2 w-full rounded-2xl border border-white/10 bg-slate-950/60 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:border-white/40 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-xs uppercase tracking-[0.2em] text-slate-400">
                Your Message
              </label>
              <textarea
                rows="4"
                placeholder="Tell me about your project"
                className="mt-2 w-full rounded-2xl border border-white/10 bg-slate-950/60 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:border-white/40 focus:outline-none"
              ></textarea>
            </div>
            <button
              type="submit"
              className="button-primary w-full"
            >
              Send Message
            </button>
          </form>
          <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 p-8 text-sm text-slate-300">
            <p className="text-sm uppercase tracking-[0.25em] text-slate-400">
              Contact Details
            </p>
            <div className="mt-6 space-y-4">
              <div className="info-row">
                <span className="info-icon">@</span>
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-400">
                    Email
                  </p>
                  <p className="text-white">hello@malik.com</p>
                </div>
              </div>
              <div className="info-row">
                <span className="info-icon">#</span>
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-400">
                    Phone
                  </p>
                  <p className="text-white">+123 456 7890</p>
                </div>
              </div>
              <div className="info-row">
                <span className="info-icon">*</span>
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-400">
                    Location
                  </p>
                  <p className="text-white">New York, USA</p>
                </div>
              </div>
            </div>
            <div className="mt-6 flex gap-3">
              <a
                href="https://github.com/yourname"
                target="_blank"
                rel="noreferrer"
                className="rounded-full border border-white/20 px-4 py-2 text-xs font-semibold text-white transition hover:border-white/50 hover:bg-white/10"
              >
                GitHub
              </a>
              <a
                href="https://linkedin.com/in/yourname"
                target="_blank"
                rel="noreferrer"
                className="rounded-full border border-white/20 px-4 py-2 text-xs font-semibold text-white transition hover:border-white/50 hover:bg-white/10"
              >
                LinkedIn
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default Contact
